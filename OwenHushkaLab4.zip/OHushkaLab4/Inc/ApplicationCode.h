/*
 * ApplicationCode.h
 *
 *  Created on: Sep 5, 2023
 *      Author: owenhushka
 */

#ifndef INC_APPLICATIONCODE_H_
#define INC_APPLICATIONCODE_H_

#define NAME_LENGTH 4
#define DELAY 250000
#include<Scheduler.h>
#include <stdint.h>
#include<Button_Driver.h>
#include<LED_Driver.h>

#define USE_INTERRUPT_FOR_BUTTON 1
#define USE_LIMITED_RESOURCES 1


#if USE_INTERRUPT_FOR_BUTTON == 1
	void InitializeInterruptMode();
#elif USE_INTERRUPT_FOR_BUTTON ==0
	void Button_Init();
#endif


void Application_Init();
void InitializeGreenLED();
void InitializeRedLED();
void InitializeBothLED();
void ToggleGreen();
void ToggleRed();
void TurnRedOn();
void TurnGreenOn();
void TurnRedOff();
void TurnGreenOff();
void Delay();

void ButtonPollingRoutine();




#endif /* INC_APPLICATIONCODE_H_ */

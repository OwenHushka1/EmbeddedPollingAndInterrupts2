/*
 * STM32F429i.h
 *
 *  Created on: Sep 5, 2023
 *      Author: owenhushka
 *
 *
 */
#ifndef INC_STM32F429I_H_
#define INC_STM32F429I_H_
#include <stdint.h>
#include<stdbool.h>

typedef struct{

	volatile uint32_t MODER; //port mode register
	volatile uint32_t OTYPER; //output type register
	volatile uint32_t OSPEEDR; //output speed register
	volatile uint32_t PUPDR; //pull up/pull down register
	volatile uint32_t IDR; //input data register
	volatile uint32_t ODR; //output data register
	volatile uint32_t BSRR; //bit set/reset register
	volatile uint32_t LCKR; //port configuration lock register
	volatile uint32_t AFR[2]; //alternate function low and high registers

}GPIO_RegDef_t;



typedef struct{

		volatile uint32_t CR; //control register
		volatile uint32_t PLLCFGR; //PLL Configuration
		volatile uint32_t CFGR; //clock configuration register
		volatile uint32_t CIR; //clock interupt register
		volatile uint32_t AHB1RSTR; //AHB1 peripheral reset register
		volatile uint32_t AHB2RSTR; //AHB2 peripheral reset register
		volatile uint32_t AHB3RSTR; //AHB3 peripheral reset register
		volatile uint32_t res0;
		volatile uint32_t APB1RSTR; //APB1 peripheral reset register
		volatile uint32_t APB2RSTR; //APB2 peripheral reset register
		volatile uint32_t res1[2];
		volatile uint32_t AHB1ENR; //AHB1 peripheral clock enable register
		volatile uint32_t AHB2ENR; //AHB2 peripheral clock enable register
		volatile uint32_t AHB3ENR; //AHB3 Peripheral clock enable register
		volatile uint32_t res2;
		volatile uint32_t APB1ENR;//APB1 peripheral clock enable
		volatile uint32_t APB2ENR;//APB2 peripheral clock enable
		volatile uint32_t res3[2];
		volatile uint32_t AHB1LPENR; //AHB1 clock enable in low power mode
		volatile uint32_t AHB2LPENR; //AHB2 clock enable in low power mode
		volatile uint32_t AHB3LPENR; //AHB3 clock enable in low power mode
		volatile uint32_t res4;
		volatile uint32_t APB1LPENR; //APB1 clock enable in low power mode
		volatile uint32_t APB2LPENR; //APB2 clock enable in low power mode
		volatile uint32_t res5[2];
		volatile uint32_t BDCR; //RCC backup domain control register
		volatile uint32_t CSR; //RCC clock control and status register
		volatile uint32_t res6[2];
		volatile uint32_t SSCGR; //spread spectrum clock generation register
		volatile uint32_t PLLI2SCFGR; //RCC PLLI2S configuration register
		volatile uint32_t PLLSAICFGR; //RCC PLL configuration register
		volatile uint32_t DCKCFGR; //Dedicated Clock Configuration Register


}RCC_RegDef_t;


typedef struct{

	volatile uint32_t MEMRMP;
	volatile uint32_t PMC;
	volatile uint32_t EXTIC[4];
	volatile uint32_t CMPCR;

}SYSCFG_RegDef_t;


typedef struct{
	volatile uint32_t IMR;
	volatile uint32_t EMR;
	volatile uint32_t RTSR;
	volatile uint32_t FTSR;
	volatile uint32_t SWIER;
	volatile uint32_t PR;

}EXTI_RegDef_t;

typedef struct{

	volatile uint32_t CR1;
	volatile uint32_t CR2;
	volatile uint32_t SMCR;
	volatile uint32_t DIER;
	volatile uint32_t SR;
	volatile uint32_t EGR;
	volatile uint32_t CCMR1;
	volatile uint32_t CCMR2;
	volatile uint32_t CCER;
	volatile uint32_t CNT;
	volatile uint16_t PSC; //prescaler value
	volatile uint32_t ARR; //31:16 High auto-reload value. 15:0 Auto-reload value
	volatile uint32_t res1;
	volatile uint32_t CCR1;
	volatile uint32_t CCR2;
	volatile uint32_t CCR3;
	volatile uint32_t CCR4;
	volatile uint32_t res2;
	volatile uint32_t DCR;
	volatile uint32_t DMAR;
	volatile uint32_t TIMx_OR;

}GPTIMR_RegDef_t;


//base addresses
#define PERIPHERAL_ADDRESS_SPACE_BASE_ADDR 0x40000000u
#define AHB1_BASE_ADDR 0x40020000u
#define APB2_BASE_ADDR 0x40010000u
#define APB1_BASE_ADDR 0x40000000u

#define GPIOG_BASE_ADDR (AHB1_BASE_ADDR + 0x1800)
#define RCC_BASE_ADDR (AHB1_BASE_ADDR + 0x3800)
#define GPIOA_BASE_ADDR (AHB1_BASE_ADDR)
#define SYSCFG_BASE_ADDR (APB2_BASE_ADDR + 0x3800)
#define EXTI_BASE_ADDR (APB2_BASE_ADDR + 0x3C00)
#define TIM2_BASE_ADDR APB1_BASE_ADDR
#define TIM5_BASE_ADDR (APB1_BASE_ADDR + 0x0C00)

#define ACTIVE 1
#define NON_ACTIVE 0
#define SET 1
#define RESET 0
#define ENABLE SET
#define DISABLE RESET

#define GPIOA ((GPIO_RegDef_t*) GPIOA_BASE_ADDR ) //pointer to GPIOA base address
#define GPIOG ((GPIO_RegDef_t*) GPIOG_BASE_ADDR ) //pointer to GPIOG base address
#define RCC ((RCC_RegDef_t*) RCC_BASE_ADDR ) //pointer to RCC base address
#define SYSCFG ((SYSCFG_RegDef_t*) SYSCFG_BASE_ADDR) //pointer to SYSCFG base address
#define EXTI ((EXTI_RegDef_t*) EXTI_BASE_ADDR) //pointer to EXTI base address
#define TIM2 ((GPTIMR_RegDef_t*) TIM2_BASE_ADDR) //macro to access TIM2 registers
#define TIM5 ((GPTIMR_RegDef_t*) TIM5_BASE_ADDR) //macro to access TIM5 register

#define TIM2_OFFSET 0
#define TIM5_OFFSET 0xC00 //Is this right?

#define AHB1_CLK_ENABLE(bit) (RCC->AHB1ENR |= 1<<bit)
#define AHB1_CLK_DISABLE(bit) (RCC->AHB1ENR &= ~1<<bit)
#define APB2_CLK_ENABLE(bit) (RCC->APB2ENR |= 1<<bit)
#define APB2_CLK_DISABLE(bit) (RCC->APB2ENR &= ~1<<bit)
#define APB1_CLK_ENABLE(bit) (RCC->APB1ENR |= 1<<bit)
#define APB1_CLK_DISABLE(bit) (RCC->APB1ENR &= ~1<<bit)


#define SYSCFG_BIT 14
#define GPIOG_BIT 6
#define GPIOA_BIT 0
#define TIM2_BIT 0
#define TIM5_BIT 3


//addresses of NVIC set enable registers
#define NVIC_ISER0 ((volatile uint32_t*) 0xE000E100)
#define NVIC_ISER1 ((volatile uint32_t*) 0xE000E104)
#define NVIC_ISER2 ((volatile uint32_t*) 0xE000E108)
#define NVIC_ISER3 ((volatile uint32_t*) 0xE000E10C)
#define NVIC_ISER4 ((volatile uint32_t*) 0xE000E110)
#define NVIC_ISER5 ((volatile uint32_t*) 0xE000E114)
#define NVIC_ISER6 ((volatile uint32_t*) 0xE000E118)
#define NVIC_ISER7 ((volatile uint32_t*) 0xE000E11C)

//address of NVIC clear enable registers
#define NVIC_ICER0 ((volatile uint32_t*) 0xE000E180)
#define NVIC_ICER1 ((volatile uint32_t*) 0xE000E184)
#define NVIC_ICER2 ((volatile uint32_t*) 0xE000E188)
#define NVIC_ICER3 ((volatile uint32_t*) 0xE000E18C)
#define NVIC_ICER4 ((volatile uint32_t*) 0xE000E190)
#define NVIC_ICER5 ((volatile uint32_t*) 0xE000E194)
#define NVIC_ICER6 ((volatile uint32_t*) 0xE000E198)
#define NVIC_ICER7 ((volatile uint32_t*) 0xE000E19C)

//address of NVIC set pending registers
#define NVIC_ISPR0 ((volatile uint32_t*) 0xE000E200)
#define NVIC_ISPR1 ((volatile uint32_t*) 0xE000E204)
#define NVIC_ISPR2 ((volatile uint32_t*) 0xE000E208)
#define NVIC_ISPR3 ((volatile uint32_t*) 0xE000E20C)
#define NVIC_ISPR4 ((volatile uint32_t*) 0xE000E210)
#define NVIC_ISPR5 ((volatile uint32_t*) 0xE000E214)
#define NVIC_ISPR6 ((volatile uint32_t*) 0xE000E218)
#define NVIC_ISPR7 ((volatile uint32_t*) 0xE000E21C)

//address of NVIC clear pending registers
#define NVIC_ICPR0 ((volatile uint32_t*) 0xE000E280)
#define NVIC_ICPR1 ((volatile uint32_t*) 0xE000E284)
#define NVIC_ICPR2 ((volatile uint32_t*) 0xE000E288)
#define NVIC_ICPR3 ((volatile uint32_t*) 0xE000E28C)
#define NVIC_ICPR4 ((volatile uint32_t*) 0xE000E290)
#define NVIC_ICPR5 ((volatile uint32_t*) 0xE000E294)
#define NVIC_ICPR6 ((volatile uint32_t*) 0xE000E298)
#define NVIC_ICPR7 ((volatile uint32_t*) 0xE000E29C)

//address of first NVIC priority register
#define NVIC_IPR0 ((volatile uint32_t*) 0xE000E400)

void InitializeGreenLED();
void InitializeRedLED();
void InitializeBothLED();


#endif /* INC_STM32F429I_H_ */


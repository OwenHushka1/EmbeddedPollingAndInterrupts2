#ifndef TIMER_DRIVER_H
#define TIMER_DRIVER_H
#include<InterruptControl.h>


typedef struct{
	uint32_t outputCompare; //Output compare 1 selection
	bool preloadEnable; 	//Output compare preload enablement
	bool fastEnable; //Output compare fast enablement
	bool clearEnable; //Output compare clear enablement
	uint32_t captureCompare;	//Capture Compare Value
	bool interruptEnable;
}CHANNEL_CONFIG_t;


typedef struct{
	//Auto Reload Value
	uint32_t AutoReloadVal; //auto reload value
	uint32_t OC1M; //Master Mode Selection, maybe make uint_32
	uint32_t CLKDIV;//Clock Division Value
	uint16_t prescalerVal; //Prescaler Value
	uint32_t centerAlignedMode; //Center Aligned Mode Selection
	bool AutoReloadBufferEnable; //Auto reload buffer enablement 0->no buffer; 1 -> buffered
	bool dir;//Timer count-down mode enablement
	bool InterruptUpdateEnable;//Interrupt update enablement
	bool DisableUpdateEvent;//Disable update event 0->enable; 1->disable
	bool PulseEnable;//One pulse mode enablement
	CHANNEL_CONFIG_t channelConfig; //Channel 1 configuration
}GPTImer_CONFIG_t;


typedef struct{
	GPTImr_RegDef_t* timer;
	GPTImer_CONFIG_t config;
}Timer_Handle_t;


void InitTimer(Timer_Handle_t *timer);
void InitChannel1(Timer_Handle_t *timer);
void ClockControl(GPTIMR_RegDef_t timer, uint8_t able);
void StartTimer(GPTIMR_RegDef_t *timer);
void StopTimer(GPTIMR_RegDef_t *timer);
void ResetTimer(GPTIMR_RegDef_t *timer);
uint32_t ReturnTimer(GPTIMR_RegDef_t *timer);
void TimerInterrupt(GPTIMR_RegDef_t *timer, uint8_t able);
void SetPriority(GPTIMR_RegDef_t *timer, uint8_t priority);


#endif /* TIMER_DRIVER_H */

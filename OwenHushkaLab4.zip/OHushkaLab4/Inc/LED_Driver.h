/*
 * LED_Driver.h
 *
 *  Created on: Sep 5, 2023
 *      Author: owenhushka
 */



#ifndef INC_LED_DRIVER_H_
#define INC_LED_DRIVER_H_


#include"GPIO_Driver.h"
#include"Timer_Driver.h"

#define RED 0
#define GREEN 1
#define TIM2DEFAULT_PRIORITY 57
#define TIM5DEFAULT_PRIORITY 35
#define ELEVATED_PRIORITY 20

void LED_Initialize_timer2();
void LED_Initialize_timer5();
void LED_Start_timer2();
void LED_Start_timer5();
void LED_Stop_timer2();  //these almost definitly need to take input arguments
void LED_Stop_timer5();
void LED_Reset_timer2();
void LED_Reset_timer5();
void LED_Eval_PriorityT2();
void LED_Eval_PriorityT5();
void LED_Restore_Default_PriorityT2();
void LED_Restore_Default_PriorityT5();

//initialize timer
//start timer
//stop timer
//reset timer
//evaluate IRQ priority
//restore priority to default

void initializeLED(uint8_t whichLED);
void enableClock(uint8_t whichLED);
void enableLED(uint8_t whichLED);
void disableLED(uint8_t whichLED);
void toggleLED(uint8_t whichLED);

#endif /* INC_LED_DRIVER_H_ */



/*
 * GPIO_Driver.h
 *
 *  Created on: Sep 5, 2023
 *      Author: Owen Hushka
 */

#ifndef INC_GPIO_DRIVER_H_
#define INC_GPIO_DRIVER_H_


#include <stdint.h>
#include <InterruptControl.h>


//pin number macros
#define GPIO_PIN0 0
#define GPIO_PIN1 1
#define GPIO_PIN2 2
#define GPIO_PIN3 3
#define GPIO_PIN4 4
#define GPIO_PIN5 5
#define GPIO_PIN6 6
#define GPIO_PIN7 7
#define GPIO_PIN8 8
#define GPIO_PIN9 9
#define GPIO_PIN10 10
#define GPIO_PIN11 11
#define GPIO_PIN12 12
#define GPIO_PIN13 13
#define GPIO_PIN14 14
#define GPIO_PIN15 15

//pin mode macros
#define INPUT 00
#define OUTPUT 01
#define ALTERNATE_FUNCTION 10
#define ANALOG 11

//output type macros
#define PUSHPULL 0
#define OPENDRAIN 1

//speed macros
#define LOW 00
#define MED 01
#define HIGH 10
#define VERY_HIGH 00

//pull up pull down macros
#define NONE 00
#define PULLUP 01
#define PULLDOWN 10
#define RESERVED 11

//interrupt modes
#define NO_INTERRUPT 0
#define FALLING_EDGE 1
#define RISING_EDGE 2
#define FALLING_AND_RISING 3

//GPIO port number
#define GPIOA_PORT_NUM 0;
#define GPIOB_PORT_NUM 1;
#define GPIOC_PORT_NUM 2;
#define GPIOD_PORT_NUM 3;
#define GPIOE_PORT_NUM 4;
#define GPIOF_PORT_NUM 5;
#define GPIOG_PORT_NUM 6;
#define GPIOH_PORT_NUM 7;
#define GPIOI_PORT_NUM 8;
#define GPIOJ_PORT_NUM 9;
#define GPIOK_PORT_NUM 10;



typedef struct
{
uint8_t PinNumber; // Pin Number
uint8_t PinMode; // Pin Mode
uint8_t OPType; // Output Type
uint8_t PinSpeed; // Pin Speed
uint8_t PinPuPdControl; // Pin Push up/ Pull Down Control
uint8_t PinAltFunMode; // Alternate Function mode
uint8_t PinInterruptMode;//pin interrupt mode
}GPIO_PinConfig_t;


typedef struct{
GPIO_RegDef_t* pGPIOx; // GPIO port
GPIO_PinConfig_t GPIO_PinConfig; // The pin configuraitons
}GPIO_Handle_t;

void GPIO_Initialize(GPIO_Handle_t *handle);
void GPIO_Clock(GPIO_RegDef_t *req, uint8_t able);
void GPIO_Toggle(GPIO_RegDef_t *req, uint8_t pinNumber);
void GPIO_WriteToInput(GPIO_RegDef_t *req, uint8_t *pinNumber, uint8_t val);
uint8_t GPIO_Read_Input(GPIO_RegDef_t *req, uint8_t pinNumber); //function to read from input pin of given port
uint16_t GPIO_GetPortCode(GPIO_RegDef_t *req);//is this the same as the last function I just made?
//should name this getportcode()

//should this be an int?
void GPIO_NVIC_INTERRUPT(uint8_t irq_num, uint8_t able); //prob need to change second variable


#endif /* INC_GPIO_DRIVER_H_ */







#include<Button_Driver.h>



void Initialize_Button(){

	GPIO_Handle_t ButtonConfig = {0};
	ButtonConfig.pGPIOx = BUTTON_PORT;
	ButtonConfig.GPIO_PinConfig.PinMode = INPUT;
	ButtonConfig.GPIO_PinConfig.PinNumber = BUTTON_PIN; //should i use the macro
	ButtonConfig.GPIO_PinConfig.PinSpeed = HIGH; //not sure if this is right
	ButtonConfig.GPIO_PinConfig.PinPuPdControl = NONE;
	Enable_Clock();
	//GPIO_Clock(ButtonConfig.pGPIOx, ENABLE);
	GPIO_Initialize(&ButtonConfig);
	ButtonConfig.GPIO_PinConfig.PinInterruptMode = NO_INTERRUPT;


	//make sure it is in input mode
}


void Initialize_Interrupt_Mode(){

	GPIO_Handle_t ButtonConfig = {0};
	ButtonConfig.GPIO_PinConfig.PinInterruptMode = FALLING_AND_RISING;

	ButtonConfig.pGPIOx = BUTTON_PORT;
	ButtonConfig.GPIO_PinConfig.PinMode = INPUT;
	ButtonConfig.GPIO_PinConfig.PinNumber = BUTTON_PIN; //should i use the macro
	ButtonConfig.GPIO_PinConfig.PinSpeed = HIGH; //not sure if this is right
	ButtonConfig.GPIO_PinConfig.PinPuPdControl = NONE;

	Enable_Clock();
	//GPIO_Clock(ButtonConfig.pGPIOx, ENABLE);
	GPIO_Initialize(&ButtonConfig);
	GPIO_NVIC_INTERRUPT(EXTI0_IRQ_NUMBER, ENABLE);

}

void Enable_Clock(){

	GPIO_Clock(BUTTON_PORT, ENABLE);
}


bool Return_Press(){

	if(GPIO_Read_Input(BUTTON_PORT, BUTTON_PORT) == BUTTON_PRESSED){
		return true;
	}
	else{
		return false;
	}
}

/*
 * ApplicationCode.c
 *
 *  Created on: Sep 5, 2023
 *      Author: owenhushka
 */

#include"ApplicationCode.h"

static uint8_t CurrentLED;
static bool redLEDStatus;
static bool greenLEDStatus;

#define TIM5IRQ 50 //IRQ number for tim5
#define TIM2IRQ 28 //IRQ number for tim4

void InitializeGreenLED(){
	initializeLED(GREEN);
}

void InitializeRedLED(){
	initializeLED(RED);
}

void InitializeBothLED(){
	initializeLED(RED);
	initializeLED(GREEN);
}

void ToggleGreen(){
	toggleLED(GREEN);
}
void ToggleRed(){
	toggleLED(RED);
}


void TurnRedOn(){
	enableLED(RED);

}
void TurnGreenOn(){
	enableLED(GREEN);

}

void TurnRedOff(){

	disableLED(RED);

}
void TurnGreenOff(){

	disableLED(GREEN);
}


void Delay(){
	char arr[NAME_LENGTH] = "Owen";
	[[maybe_unused]]char destination[NAME_LENGTH];

	for(int i = 0; i < DELAY; i++){
		for(int k = 0; k < 4; k++){
			destination[k] = arr[k];

			//do I need to clear the destination array after adding all of the values?
		}
	}
}

void InitializeInterruptMode(){

	Initialize_Interrupt_Mode();
}


void Button_Init(){
	Initialize_Button();
}

void Application_Init(){
	#if USE_INTERRUPT_FOR_BUTTON != 0
		InitializeInterruptMode();
	#else
		Button_Init();
	#endif


	InitializeGreenLED();  //different LED than last time
	InitializeRedLED();
	CurrentLED = GREEN; //setting CurrentLED to green LED macro
	TurnGreenOff();//deactivate LED so it's at known state
	TurnRedOff();
	greenLEDStatus = 0;
	redLEDStatus = 0;
	LED_Initialize_timer2();
	LED_Initialize_timer5();
	LED_Start_timer2();
	LED_Start_timer5();
	//addSchedulerEvent(LED_TOGGLE_EVENT);//add LED toggle event
	addSchedulerEvent(DELAY_EVENT);//add Delay event
	addSchedulerEvent(POLL_BUTTON_EVENT);

	//verify delay event is added to scheduler

}



void ButtonPollingRoutine(){
	if(Return_Press()){
		TurnGreenOn();

	}
	else{
		TurnGreenOff();
	}
}

void EXTI0_IRQHandler(){
	IRQ_DISABLE_INTERRUPT(EXTI0_IRQ_NUMBER);

	//if button is pressed, record the time it took from the thing to display to the button pressed?

	#if USE_LIMITED_RESOURCES == 1

		TurnGreenOff();//deactivate LED so it's at known state
		TurnRedOff();
		greenLEDStatus = 0;
		redLEDStatus = 0;

	#else
		LED_Reset_timer2();
		LED_Reset_timer5();

	#endif

//	IRQ_DISABLE_INTERRUPT(EXTI0_IRQ_NUMBER);
//	if(CurrentLED == GREEN){
//		ToggleGreen();
//		greenLEDStatus = !greenLEDStatus;
//	}

	EXTI_INTERRUPT_CLEAR(BUTTON_PIN);
	IRQ_ENABLE_INTERRUPT(EXTI0_IRQ_NUMBER);
	IRQ_ENABLE_INTERRUPT(TIM2IRQ);
}

void TIM2_IRQHandler(){
	IRQ_DISABLE_INTERRUPT(TIM2IRQ);
	//EXTI_PR set to 0 to clear flag
	//still need to clear NVIC interrupt?
	IRQ_ENABLE_INTERRUPT(EXTI0_IRQ_NUMBER);
	if(TIM2->SR & (1<<1)){
		#if USE_LIMITED_RESOURCES == 0
			ToggleGreen();
			greenLEDStatus = !greenLEDStatus;
		#else
			if(greenLEDStatus){
				TurnGreenOff();
				greenLEDStatus = false;
				LED_Restore_Default_PriorityT2();
			}
			else if(!redLEDStatus){
				TurnGreenOn();
				greenLEDStatus = true;
				//should have elevated priority
				LED_Eval_PriorityT2();

			}

		#endif
	}
	(TIM2->SR &= ~(1<<1));
	IRQ_CLEAR_INTERRUPT(TIM2IRQ);
	IRQ_ENABLE_INTERRUPT(TIM2IRQ);

}

void TIM5_IRQHandler(){
	IRQ_DISABLE_INTERRUPT(TIM5IRQ);
	//IRQ_ENABLE_INTERRUPT(6);
	if(TIM5->SR & (1<<1)){
	#if USE_LIMITED_RESOURCES == 0
	   ToggleRed();
	   redLEDStatus = !redLEDStatus;

	#else

	   if(redLEDStatus){
		   TurnRedOff();
		   redLEDStatus = false;
		   LED_Restore_Default_PriorityT5();

	   }
	   else{
		   if(!greenLEDStatus){
			   LED_Eval_PriorityT5();
			   TurnRedOn();
			   redLEDStatus = true;
		   }
	   }

	#endif
	}
	((TIM5->SR) &= ~(1<<1));
	IRQ_CLEAR_INTERRUPT(TIM5IRQ);
	IRQ_ENABLE_INTERRUPT(TIM5IRQ);

}


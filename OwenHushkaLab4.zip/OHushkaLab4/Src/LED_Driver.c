/*
 * LED_Driver.c
 *
 *  Created on: Sep 5, 2023
 *      Author: owenhushka
 */


#include <LED_Driver.h>

#define AUTO_RELOAD_VAL 0x1100000
#define PRESCALER_VAL 0


#define AUTO_RELOAD1 0x1000000
#define AUTO_RELOAD2 0x1000000+0x1000000
#define CAPTURE_COMPARE_VALUE 0x8000

//master mode selection macros
#define RESETT 000
#define ENABLEE 001
#define UPDATE 010
#define COMPARE_PULSE 011
#define COMPARE_OC1REF 100 //Compare - OC1REF signal is used as trigger output (TRGO)
#define COMPARE_OC2REF 101 //Compare - OC2REF signal is used as trigger output (TRGO)
#define COMPARE_OC3REF 110 //Compare - OC3REF signal is used as trigger output (TRGO)
#define COMPARE_OC4REF 111 //Compare - OC4REF signal is used as trigger output (TRGO)



//output compare mode macros

#define FROZEN 000
#define ACTIVEE 001 //Set channel 1 to active level on match
#define INACTIVE 010 //Set channel 1 to inactive level on match
#define TOGGLE 011 //Toggle - OC1REF toggles when TIMx_CNT=TIMx_CCR1
#define FORCE_INACTIVE 100 //OC1REF is forced low
#define FORCE_ACTIVE 101 //OC1REF is forced high.
#define PMW_MODE1 110 //- In up counting, channel 1 is active as long as TIMx_CNT<TIMx_CCR1 else inactive. In down counting, channel 1 is inactive (OC1REF=‘0) as long as TIMx_CNT>TIMx_CCR1 else active (OC1REF=1).
#define PMW_MODE2 111 //- In up counting, channel 1 is inactive as long as TIMx_CNT<TIMx_CCR1 else active. In down counting, channel 1 is active as long as TIMx_CNT>TIMx_CCR1 else inactive

//In PWM mode 1 or 2, the OCREF level changes only when the result of the
//comparison changes or when the output compare mode switches from “frozen” mode
//to “PWM” mode.


//Capture Compare
#define OUTPUT1 00
#define INPUT1 01 //CC1 channel is configured as input, IC1 is mapped on TI1
#define INPUT2 10 //CC1 channel is configured as input, IC1 is mapped on TI2.
#define INPUT3 11 //CC1 channel is configured as input, IC1 is mapped on TRC. This mode is working only if an internal trigger input is selected through TS bit (TIMx_SMCR register)


//center alligned mode selection
#define EDGE_ALIGNED 00
#define CENTER_ALIGNED_1 01
#define CENTER_ALIGNED_2 10
#define CENTER_ALIGNED_3 11


//output compare 1 modes
#define FROZEN 000
#define ACTIVEE 001
#define INACTIVE 010
#define TOGGLE 011
#define FORCE_INACTIVE 100
#define FORCE_ACTIVE 101
#define PWM1 110
#define PWM2 111

//direction macros
#define UPCOUNTER 0
#define DOWNCOUNTER 1

//clock division macros
#define INT 0
#define DOUBLE_INT 01
#define FOUR_X_INT 10

//auto reload buffer macros
#define NO_BUFFER 0//0: TIMx_ARR register is not buffered
#define BUFFER 1 //1: TIMx_ARR register is buffered


static GPIO_Handle_t RedLED;
static GPIO_Handle_t GreenLED;
static Timer_Handle_t config;

//Do I still need to add the clock initialization function?
void initializeLED(uint8_t whichLED){

	switch (whichLED){
	  case RED:
		  RedLED.GPIO_PinConfig.PinMode = OUTPUT;
		  RedLED.GPIO_PinConfig.PinPuPdControl = NONE;
		  RedLED.GPIO_PinConfig.PinSpeed = HIGH;
		  RedLED.GPIO_PinConfig.PinNumber = 14;
		  RedLED.GPIO_PinConfig.OPType = PUSHPULL;
		  RedLED.pGPIOx = GPIOG;
		  GPIO_Clock(RedLED.pGPIOx, ENABLE);
		  GPIO_Initialize(&RedLED);

	    	break;

	  case GREEN:
		  GreenLED.GPIO_PinConfig.PinMode = OUTPUT;
		  GreenLED.GPIO_PinConfig.PinSpeed = HIGH;
		  GreenLED.GPIO_PinConfig.PinNumber = 13;
		  GreenLED.GPIO_PinConfig.OPType = PUSHPULL;
		  GreenLED.GPIO_PinConfig.PinPuPdControl = NONE;

		  GreenLED.pGPIOx = GPIOG;
		  GPIO_Clock(GreenLED.pGPIOx, ENABLE);
		  GPIO_Initialize(&GreenLED);
	   		break;

	}
}


void toggleLED(uint8_t whichLED){
	switch (whichLED){
	case RED:
		//GPIO_Toggle(GPIO_RegDef_t *req, uint8_t *pinNumber){
		GPIO_Toggle(RedLED.pGPIOx, RedLED.GPIO_PinConfig.PinNumber);//not certain this is the right pin number
		break;

	case GREEN:
		GPIO_Toggle(GreenLED.pGPIOx, GreenLED.GPIO_PinConfig.PinNumber);
		//GPIO_Toggle(GPIO_RegDef_t *req, uint8_t *pinNumber){
	break;}
}


void disableLED(uint8_t whichLED){

	switch (whichLED){

	case RED:
		GPIO_WriteToInput(RedLED.pGPIOx, &RedLED.GPIO_PinConfig.PinNumber,DISABLE);

		break;

	case GREEN:
		GPIO_WriteToInput(GreenLED.pGPIOx, &GreenLED.GPIO_PinConfig.PinNumber,DISABLE);

		break;
	}
}

void enableLED(uint8_t whichLED){

	switch (whichLED){

	case RED:
		GPIO_WriteToInput(RedLED.pGPIOx, &RedLED.GPIO_PinConfig.PinNumber, ENABLE);

		break;

	case GREEN:
		GPIO_WriteToInput(GreenLED.pGPIOx, &GreenLED.GPIO_PinConfig.PinNumber, ENABLE);

		break;
	}

}

void LED_Initialize_timer2(){


	APB1_CLK_ENABLE(0);//Enable bit 0 of clock for TIM2
	initializeLED(0); //Red LED
	config.config.AutoReloadVal = AUTO_RELOAD1;//0x1000000
	config.config.prescalerVal = PRESCALER_VAL;

	config.timer = TIM2;
	config.config.centerAlignedMode = EDGE_ALIGNED;
	config.config.CLKDIV = INT;
	config.config.dir = false;
	config.config.AutoReloadBufferEnable = false;
	config.config.PulseEnable = false;
	config.config.DisableUpdateEvent = true;
	config.config.channelConfig.outputCompare = FROZEN;
	config.config.channelConfig.captureCompare = CENTER_ALIGNED_1;
	config.config.channelConfig.preloadEnable = false;
	config.config.channelConfig.fastEnable = false;
	config.config.channelConfig.interruptEnable = true;
	config.config.channelConfig.clearEnable = false;
	config.config.channelConfig.captureCompare = CAPTURE_COMPARE_VALUE;
	TimerInterrupt(config.timer, ENABLE);
	InitTimer(&config);

}

void LED_Initialize_timer5(){


	config.timer = TIM5;
	config.config.centerAlignedMode = EDGE_ALIGNED;
	config.config.CLKDIV = INT;
	config.config.dir = false;
	config.config.AutoReloadBufferEnable = false;
	config.config.PulseEnable = false;
	config.config.DisableUpdateEvent = true;
	config.config.prescalerVal = PRESCALER_VAL;
	config.config.AutoReloadVal = AUTO_RELOAD_VAL; //0x1000000+0x1000000
	config.config.channelConfig.outputCompare = FROZEN;
	config.config.channelConfig.captureCompare = CENTER_ALIGNED_1;
	config.config.channelConfig.preloadEnable = false;
	config.config.channelConfig.fastEnable = false;
	config.config.channelConfig.interruptEnable = true;
	config.config.channelConfig.clearEnable = false;
	config.config.channelConfig.captureCompare = CAPTURE_COMPARE_VALUE;

	APB1_CLK_ENABLE(3); // enable bit 3 for TIM5
	initializeLED(1); //Green LED
	TimerInterrupt(&config.timer, ENABLE);
	InitTimer(&config);

}

void LED_Start_timer2(){

	StartTimer(TIM2);

}
void LED_Start_timer5(){

	StartTimer(TIM5);

}
void LED_Stop_timer2(){

	StopTimer(TIM2);

}
void LED_Stop_timer5(){

	StopTimer(TIM5);

}
void LED_Reset_timer2(){

	ResetTimer(TIM2);

}
void LED_Reset_timer5(){

	ResetTimer(TIM5);

}


void LED_Eval_PriorityT2(){

	//set priority to ELEVATED_PRIORITY
	IRQ_ConfigurePriority(TIM2_IRQ_NUM, ELEVATED_PRIORITY);

}

void LED_Eval_PriorityT5(){

	//set priority to ELEVATED_PRIORITY
	IRQ_ConfigurePriority(TIM5_IRQ_NUM, ELEVATED_PRIORITY);

}

void LED_Restore_Default_PriorityT2(){

	//set priority to TIM5DEFAULT_PRIORITY
	IRQ_ConfigurePriority(TIM2_IRQ_NUM, TIM2DEFAULT_PRIORITY);

}

void LED_Restore_Default_PriorityT5(){

	//set priority to TIM2DEFAULT_PRIORITY
	IRQ_ConfigurePriority(TIM5_IRQ_NUM, TIM5DEFAULT_PRIORITY);

}

